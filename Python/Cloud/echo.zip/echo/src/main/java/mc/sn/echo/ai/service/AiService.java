package mc.sn.echo.ai.service;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;

import org.springframework.stereotype.Service;

@Service("aiService")
public class AiService {
	
	//占쏙옙트占싼뤄옙占쏙옙占쏙옙 占쏙옙占쏙옙占쏙옙 text占쏙옙 占쏙옙占쏙옙占쌔쇽옙 占쏙옙占쏙옙占싹댐옙 占쏙옙占쏙옙占쏙옙 占싹댐옙 占쌨소듸옙 占쏙옙占쏙옙
	public String translate(String words) {
		 //String result = "占쏙옙占쏙옙占싹뤄옙";
		 StringBuffer res = null;
		 String clientId = "f1dr0ch09q";//占쏙옙占시몌옙占쏙옙占싱쇽옙 클占쏙옙占싱억옙트 占쏙옙占싱듸옙";
	     String clientSecret = "lPo5FiMFhTkIIF1A76fJDWhKFFc0t3wjK5Rg1JTb";//占쏙옙占시몌옙占쏙옙占싱쇽옙 클占쏙옙占싱억옙트 占쏙옙크占쏙옙占쏙옙";
	     try {
	         String text = URLEncoder.encode(words, "UTF-8");
	         String apiURL = "https://naveropenapi.apigw.ntruss.com/nmt/v1/translation";
	         URL url = new URL(apiURL);
	         HttpURLConnection con = (HttpURLConnection)url.openConnection();
	         con.setRequestMethod("POST");
	         con.setRequestProperty("X-NCP-APIGW-API-KEY-ID", clientId);
	         con.setRequestProperty("X-NCP-APIGW-API-KEY", clientSecret);
	         // post request
	         String postParams = "source=ko&target=en&text=" + text;
	         con.setDoOutput(true);
	         DataOutputStream wr = new DataOutputStream(con.getOutputStream());
	         wr.writeBytes(postParams);
	         wr.flush();
	         wr.close();
	         int responseCode = con.getResponseCode();
	         BufferedReader br;
	         if(responseCode==200) { // 占쏙옙占쏙옙 호占쏙옙
	             br = new BufferedReader(new InputStreamReader(con.getInputStream()));
	         } else {  // 占쏙옙占쏙옙 占쌩삼옙
	             br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
	         }
	         String inputLine;
	         res = new StringBuffer();
	         while ((inputLine = br.readLine()) != null) {
	             res.append(inputLine);
	         }
	         br.close();
	         System.out.println("service "+res.toString());
	     } catch (Exception e) {
	         System.out.println(e);
	     }
		
	
		return res.toString();
	}
	
	public String clovaSpeechToText(String filePathName, String language) {
		// TODO Auto-generated method stub
		String clientId = "f1dr0ch09q";             // Application Client ID";
        String clientSecret = "lPo5FiMFhTkIIF1A76fJDWhKFFc0t3wjK5Rg1JTb";     // Application Client Secret";
        String result = null;
        try {
            String imgFile = filePathName;
            File voiceFile = new File(imgFile);

            //String language = "Kor";        // 占쏙옙占� 占쌘듸옙 ( Kor, Jpn, Eng, Chn )
            String apiURL = "https://naveropenapi.apigw.ntruss.com/recog/v1/stt?lang=" + language;
            //System.out.println(apiURL);
            URL url = new URL(apiURL);

            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setUseCaches(false);
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestProperty("Content-Type", "application/octet-stream");
            conn.setRequestProperty("X-NCP-APIGW-API-KEY-ID", clientId);
            conn.setRequestProperty("X-NCP-APIGW-API-KEY", clientSecret);

            OutputStream outputStream = conn.getOutputStream();
            FileInputStream inputStream = new FileInputStream(voiceFile);
            byte[] buffer = new byte[4096];
            int bytesRead = -1;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            outputStream.flush();
            inputStream.close();
            BufferedReader br = null;
            int responseCode = conn.getResponseCode();
            if(responseCode == 200) { // 占쏙옙占쏙옙 호占쏙옙
                br = new BufferedReader(new InputStreamReader(conn.getInputStream(),"utf8"));
            } else {  // 占쏙옙占쏙옙 占쌩삼옙
                System.out.println("error!!!!!!! responseCode= " + responseCode);
                br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            }
            String inputLine;
            
            if(br != null) {
                StringBuffer response = new StringBuffer();
                while ((inputLine = br.readLine()) != null) {
                    response.append(inputLine);
                }
                br.close();
                System.out.println(response.toString());
                result = response.toString();
            } else {
                System.out.println("error !!!");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
      
		return result;
	}

	
	
	
}
