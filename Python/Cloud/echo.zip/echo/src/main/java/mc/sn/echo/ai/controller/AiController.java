package mc.sn.echo.ai.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import mc.sn.echo.ai.service.AiService;

@Controller("aiController")
public class AiController {
	@Autowired
	private AiService aiService;
	
	@ResponseBody
	@RequestMapping(value="/translate" ,method = RequestMethod.GET)
	public void service1(@RequestParam("text") String text, 
			           HttpServletRequest request, HttpServletResponse response) throws Exception{
		request.setCharacterEncoding("utf-8");
		System.out.println(text);
		//브라우저 이동 없이 직접 브라우저에 데이터를 전달하는 코드 작성
		String result = aiService.translate(text);
		response.setContentType("text/html; charset=UTF-8");
		response.getWriter().print(result);
	}
	
	@RequestMapping(value = "/view_translate", method = RequestMethod.GET)
	public ModelAndView login(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String url = "/service/translate";
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value = "/view_stt", method = RequestMethod.GET)
	public ModelAndView stt(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String url = "/service/sttResult";
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/clovaSTT", produces = "application/text; charset=UTF-8", method =RequestMethod.POST)
	@ResponseBody
	public String stt(@RequestParam("uploadFile") MultipartFile file,
								@RequestParam("language") String language) {
		String result = "";
		System.out.println(language);
		try {
			//1. 파일 저장 경로 설정 : 실제 서비스 되는 위치 (프로젝트 외부에 저장)
			  String uploadPath =  "c:/ai/";
			  
			  //2.원본 파일 이름
			  String originalFileName = file.getOriginalFilename();  
			  
			  //3. 파일 생성 
			  String filePathName = uploadPath + originalFileName;
			  File file1 = new File(filePathName);
			  System.out.println(filePathName);
			  //4. 서버로 전송
			  file.transferTo(file1);
			  
			  result = aiService.clovaSpeechToText(filePathName, language);
			  System.out.println("ai "+result);
			  
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
}
