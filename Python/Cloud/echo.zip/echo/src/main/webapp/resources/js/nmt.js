/**
 * service {"message":{"@type":"response","@service":"naverservice.nmt.proxy",
 "@version":"1.0.0",
 "result":{
 "srcLangType":"ko",
 "tarLangType":"en",
 "translatedText":"Hello, nice to meet you."}}}
 
 */
alert('outside jsfile');
function sendWords(){
		words = $('#words').val();
		alert(words); // 1번
		$.ajax({
	         type:"get",
	         url:"/echo/translate",
	         contentType: "application/json",
	         data :{'text':$("#words").val()},
		     success:function (data,textStatus){
		    	  alert(data); // 2번
		    	  resultText = JSON.parse(data);
		    	  text = resultText.message.result.translatedText;
		    	  alert('a '+text); // 3번
		    	  $('#message').text(text);
		     },
		     error:function(data,textStatus){
		        alert("에러가 발생했습니다. "+" "+data.responseText);
		     },
		     complete:function(data,textStatus){
		    	 
		     }
		  });
	}